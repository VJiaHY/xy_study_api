package com.xyf.login_service.mapper;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AccountMapper {
}
